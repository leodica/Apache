# frozen_string_literal: true
name              'test'
maintainer        'Sous Chefs'
maintainer_email  'help@sous-chefs.org'
license           'Apache-2.0'
description       'Testing cookbook for apache2'
version           '0.0.1'

depends           'apache2'
depends           'apt'
